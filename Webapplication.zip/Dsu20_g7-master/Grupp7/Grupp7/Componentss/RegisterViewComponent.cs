﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Grupp7.Componentss
{
    public class RegisterViewComponent
    {
    }
}
